package com.springboot.project4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project4Application {

    public static void main(String[] args) {
        SpringApplication.run(Project4Application.class, args);
    }

}
